 #include <iostream>
 #include <cstdlib>
 #include <cmath>

 bool isprime(int n);
 int largest_prime(int m);

 int main(int argc, char *argv[]) {
   int m = std::atoi(argv[1]);

   std::cout << largest_prime(m) << "\n";

   return 0;
 }

 int largest_prime(int n)
 {
   TODO: Elimine esta linea e implmente la solucion
 }

 int isprime(int n)
 {
   TODO: Elimine esta linea e implmente la solucion
 }
