   #include <iostream>
   #include <cstdlib>

   void print_digits(int num);

   int main(int argc, char *argv[]) {
     int a = std::atoi(argv[1]);

     print_digits(a);

     return 0;
   }
      void print_digits(int num)
      {
        TODO: Remove this line and complete the function
      }
