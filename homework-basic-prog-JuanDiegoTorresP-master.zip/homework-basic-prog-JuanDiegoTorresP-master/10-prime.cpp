 #include <iostream>
 #include <cstdlib>
 #include <cmath>

 bool isprime(int n);

 int main(int argc, char *argv[]) {
   int m = std::atoi(argv[1]);

   std::cout << isprime(m) << "\n";

   return 0;
 }

 bool isprime(int n)
 {
   TODO: Elimine esta linea e implemente la solucion
 }
